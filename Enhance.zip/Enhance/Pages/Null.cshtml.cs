using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Enhance.Pages
{
    public class NullModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
