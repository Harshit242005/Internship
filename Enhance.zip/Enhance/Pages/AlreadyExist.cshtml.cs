using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Enhance.Pages
{
    public class AlreadyExistModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
